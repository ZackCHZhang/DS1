package de.uni_stuttgart.ipvs.ids.communication;

import java.io.Serializable;

public class RequestReadVote implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9081973891723501579L;

}
