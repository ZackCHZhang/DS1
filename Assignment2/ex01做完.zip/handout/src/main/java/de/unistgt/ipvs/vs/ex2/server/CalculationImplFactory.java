package de.unistgt.ipvs.vs.ex2.server;



/**
 * Change this class (implementation/signature/...) as necessary to complete the assignment.
 * You may also add some fields or methods.
 */

 public class CalculationImplFactory  {
 	private static final long serialVersionUID = 8409100566761383094L;
 
 	
 
 }
